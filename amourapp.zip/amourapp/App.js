import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  SafeAreaView,
  ScrollView,
  Switch,
  TextInput,
  StatusBar,
  Dimensions,
  Alert,
  Modal,
} from 'react-native';

const { width } = Dimensions.get('window');

const COSTO_POR_MINUTO_LLAMADA = 5;
const COSTO_MULTIMEDIA = 2;

const RECOMPENSA_POR_OPORTUNIDAD = 150;
const SEGUNDOS_ESPERA_OPORTUNIDAD = 10;
const OPORTUNIDADES_POR_DIA = 500;
const MAX_OPORTUNIDADES_ACUMULADAS = 1000;
const SEGUNDOS_POR_DIA = 24 * 60 * 60;

const RECOMPENSAS_CALENDARIO = [
  { dia: 'Día 1', monedas: 100 },
  { dia: 'Día 2', monedas: 300 },
  { dia: 'Día 3', monedas: 500 },
  { dia: 'Día 4', monedas: 600 },
  { dia: 'Día 5', monedas: 700 },
  { dia: 'Día 6', monedas: 900 },
  { dia: 'Día 7', monedas: 2000 },
];

const FILTROS_FOTO = [
  { id: 'normal', nombre: 'Normal', overlayColor: 'transparent', marcoExtra: 'transparent' },
  { id: 'bn', nombre: 'Blanco y Negro', overlayColor: 'rgba(120, 120, 120, 0.45)', marcoExtra: '#9CA3AF' },
  { id: 'colorido', nombre: 'Muy Colorido', overlayColor: 'rgba(255, 64, 129, 0.16)', marcoExtra: '#F43F5E' },
  { id: 'saturado', nombre: 'Muy Saturado', overlayColor: 'rgba(245, 158, 11, 0.24)', marcoExtra: '#F59E0B' },
  { id: 'pelicula', nombre: 'Película', overlayColor: 'rgba(20, 83, 105, 0.28)', marcoExtra: '#38BDF8' },
];

const FOTOS_MUESTRA_GALERIA = [
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
];

const TEMAS = {
  rosado: {
    nombre: 'Rosado',
    muestra: '#FF5E7E',
    primario: '#FF5E7E',
    secundario: '#FFE5EC',
    fondo: '#FFF8F9',
    tarjeta: '#FFFFFF',
    texto: '#3D262E',
    subtexto: '#8C6D77',
    borde: '#F5E1E6',
    loginFondo: '#FF6B8B',
    loginAcento: '#FF8FA8',
    barraEstado: 'dark-content',
  },
  rojo: {
    nombre: 'Rojo',
    muestra: '#D90429',
    primario: '#D90429',
    secundario: '#FFE3E8',
    fondo: '#FFF6F7',
    tarjeta: '#FFFFFF',
    texto: '#2B090E',
    subtexto: '#7A4950',
    borde: '#F2D5DA',
    loginFondo: '#B80021',
    loginAcento: '#E01E37',
    barraEstado: 'dark-content',
  },
  negro: {
    nombre: 'Negro',
    muestra: '#121212',
    primario: '#FF4D6D',
    secundario: '#2A1D24',
    fondo: '#121212',
    tarjeta: '#1E1E22',
    texto: '#F8F9FA',
    subtexto: '#A69FA3',
    borde: '#2E2E34',
    loginFondo: '#0D0D0F',
    loginAcento: '#26141C',
    barraEstado: 'light-content',
  },
  blanco: {
    nombre: 'Blanco',
    muestra: '#FFFFFF',
    primario: '#222222',
    secundario: '#F0F0F2',
    fondo: '#F9F9FB',
    tarjeta: '#FFFFFF',
    texto: '#18181B',
    subtexto: '#71717A',
    borde: '#E4E4E7',
    loginFondo: '#18181B',
    loginAcento: '#27272A',
    barraEstado: 'dark-content',
  },
};

const ACCESORIOS_PERFIL = [
  { id: 'acc_ninguno', nombre: 'Estilo Clásico', insignia: 'Miembro', colorMarco: '#9CA3AF', precio: 0, descripcion: 'Borde limpio sin adornos extra.' },
  { id: 'acc_elegante', nombre: 'Marco Elegante', insignia: '✦ Elegante', colorMarco: '#E5E7EB', precio: 5, descripcion: 'Acento plateado sobrio para destacar.' },
  { id: 'acc_imponente', nombre: 'Aura Imponente', insignia: '♛ Imponente', colorMarco: '#F59E0B', precio: 12, descripcion: 'Borde dorado con presencia notable.' },
  { id: 'acc_royal', nombre: 'Soberano Rubí', insignia: '♦ Soberano', colorMarco: '#E11D48', precio: 20, descripcion: 'Marco carmesí elegante para tu perfil.' },
  { id: 'acc_celestial', nombre: 'Estela Imperial', insignia: '★ Imperial', colorMarco: '#38BDF8', precio: 25, descripcion: 'Borde celeste luminoso de alto estilo.' },
  { id: 'acc_06', nombre: 'Brisa Pastel', insignia: '❀ Pastel', colorMarco: '#F9A8D4', precio: 35, descripcion: 'Detalle suave en rosa pastel.' },
  { id: 'acc_07', nombre: 'Menta Serena', insignia: '❖ Menta', colorMarco: '#6EE7B7', precio: 50, descripcion: 'Borde fresco tono menta.' },
  { id: 'acc_08', nombre: 'Lavanda Nocturna', insignia: '☾ Lavanda', colorMarco: '#C4B5FD', precio: 75, descripcion: 'Toque violeta suave para tu retrato.' },
  { id: 'acc_09', nombre: 'Atardecer Ámbar', insignia: '☀ Ámbar', colorMarco: '#FBBF24', precio: 100, descripcion: 'Luz cálida de tarde en tu marco.' },
  { id: 'acc_10', nombre: 'Azul Horizonte', insignia: '◈ Horizonte', colorMarco: '#60A5FA', precio: 140, descripcion: 'Marco azul limpio y moderno.' },
  { id: 'acc_11', nombre: 'Esmeralda Pura', insignia: '◆ Esmeralda', colorMarco: '#10B981', precio: 190, descripcion: 'Acento verde intenso elegante.' },
  { id: 'acc_12', nombre: 'Coral Encanto', insignia: '♥ Coral', colorMarco: '#FB7185', precio: 250, descripcion: 'Borde coral cálido y distintivo.' },
  { id: 'acc_13', nombre: 'Plata Pulida', insignia: '✧ Plata', colorMarco: '#CBD5E1', precio: 320, descripcion: 'Acabado metálico sobrio.' },
  { id: 'acc_14', nombre: 'Oro Rosado', insignia: '✿ Oro Rosa', colorMarco: '#F472B6', precio: 400, descripcion: 'Marco sofisticado en tono oro rosa.' },
  { id: 'acc_15', nombre: 'Cian Eléctrico', insignia: '⚡ Cian', colorMarco: '#22D3EE', precio: 500, descripcion: 'Borde brillante de alta visibilidad.' },
  { id: 'acc_16', nombre: 'Marfil Real', insignia: '♙ Marfil', colorMarco: '#FEF3C7', precio: 650, descripcion: 'Estilo clásico refinado.' },
  { id: 'acc_17', nombre: 'Zafiro Profundo', insignia: '❖ Zafiro', colorMarco: '#2563EB', precio: 800, descripcion: 'Marco azul intenso con carácter.' },
  { id: 'acc_18', nombre: 'Violeta Imperial', insignia: '♛ Violeta', colorMarco: '#8B5CF6', precio: 1000, descripcion: 'Presencia elegante en tono púrpura.' },
  { id: 'acc_19', nombre: 'Cobre Antiguo', insignia: '⚙ Cobre', colorMarco: '#D97706', precio: 1250, descripcion: 'Acento cobrizo de estilo clásico.' },
  { id: 'acc_20', nombre: 'Rosa Terciopelo', insignia: '✦ Terciopelo', colorMarco: '#DB2777', precio: 1500, descripcion: 'Marco intenso de gala.' },
  { id: 'acc_21', nombre: 'Turquesa Caribe', insignia: '🌊 Turquesa', colorMarco: '#14B8A6', precio: 1850, descripcion: 'Borde vibrante de agua marina.' },
  { id: 'acc_22', nombre: 'Carmesí Noble', insignia: '♦ Noble', colorMarco: '#BE123C', precio: 2200, descripcion: 'Marco rojo profundo de distinción.' },
  { id: 'acc_23', nombre: 'Oro Solar', insignia: '☀ Solar', colorMarco: '#EAB308', precio: 2600, descripcion: 'Resplandor dorado de alto nivel.' },
  { id: 'acc_24', nombre: 'Indigo Astral', insignia: '✦ Astral', colorMarco: '#4F46E5', precio: 3000, descripcion: 'Estilo nocturno profundo y elegante.' },
  { id: 'acc_25', nombre: 'Diamante Ártico', insignia: '❄ Ártico', colorMarco: '#7DD3FC', precio: 3400, descripcion: 'Marco cristalino de lujo.' },
  { id: 'acc_26', nombre: 'Fénix Carmín', insignia: '🔥 Fénix', colorMarco: '#EF4444', precio: 3800, descripcion: 'Borde audaz con energía.' },
  { id: 'acc_27', nombre: 'Jade Imperial', insignia: '❀ Jade', colorMarco: '#059669', precio: 4200, descripcion: 'Estilo sereno y de gran presencia.' },
  { id: 'acc_28', nombre: 'Amatista Real', insignia: '♛ Amatista', colorMarco: '#A855F7', precio: 4500, descripcion: 'Marco exclusivo en tono amatista.' },
  { id: 'acc_29', nombre: 'Platino Supremo', insignia: '★ Supremo', colorMarco: '#F8FAFC', precio: 4800, descripcion: 'Acabado luminoso de élite.' },
  { id: 'acc_30', nombre: 'Corona de Amour', insignia: '👑 Leyenda', colorMarco: '#FACC15', precio: 5000, descripcion: 'El accesorio máximo de la colección (5,000 monedas).' },
];

const PERFILES_BASE = [
  {
    id: 'base_1',
    correo: 'sofia@amour.app',
    nombre: 'Sofía',
    edad: 24,
    distancia: 'A 3 km de ti',
    bio: 'Amante del café por la mañana, los atardeceres y las buenas conversaciones.',
    imagen: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'base_2',
    correo: 'valeria@amour.app',
    nombre: 'Valeria',
    edad: 26,
    distancia: 'A 5 km de ti',
    bio: 'Fotografía, música indie y planes tranquilos para conocer gente auténtica.',
    imagen: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
  },
];

const CHATS_INICIALES = [
  {
    id: 'chat_sofia',
    correo: 'sofia@amour.app',
    nombre: 'Sofía',
    ultimoMensaje: 'Me encantaría ir por ese café este viernes.',
    hora: '10:42 AM',
    noLeido: true,
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80',
    mensajes: [
      { id: 'm1', autor: 'ellos', tipo: 'texto', texto: '¡Hola! Qué gusto hacer match contigo.', hora: '10:40 AM' },
    ],
  },
  {
    id: 'chat_camila',
    correo: 'camila@amour.app',
    nombre: 'Camila',
    ultimoMensaje: '¿Cuál es tu película favorita?',
    hora: 'Ayer',
    noLeido: false,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    mensajes: [
      { id: 'm3', autor: 'ellos', tipo: 'texto', texto: '¿Cuál es tu película favorita?', hora: 'Ayer' },
    ],
  },
];

const formatearReloj = (segundosTotales) => {
  const mins = Math.floor(segundosTotales / 60);
  const segs = segundosTotales % 60;
  return `${String(mins).padStart(2, '0')}:${String(segs).padStart(2, '0')}`;
};

const formatear24Horas = (segundosRestantes) => {
  const seguro = Math.max(0, segundosRestantes);
  const horas = Math.floor(seguro / 3600);
  const mins = Math.floor((seguro % 3600) / 60);
  const segs = seguro % 60;
  return `${String(horas).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(segs).padStart(2, '0')}`;
};

const calcularOportunidadesActualizadas = (cuenta, nowSeg) => {
  const baseOp =
    typeof cuenta.oportunidadesDisponibles === 'number'
      ? cuenta.oportunidadesDisponibles
      : OPORTUNIDADES_POR_DIA;
  const ultimaMarca = cuenta.ultimoDiaOportunidadesSeg || nowSeg;
  const diasPasados = Math.floor(Math.max(0, nowSeg - ultimaMarca) / SEGUNDOS_POR_DIA);

  if (diasPasados <= 0) {
    return {
      oportunidadesDisponibles: Math.min(MAX_OPORTUNIDADES_ACUMULADAS, baseOp),
      ultimoDiaOportunidadesSeg: ultimaMarca,
    };
  }

  const acumuladas = Math.min(
    MAX_OPORTUNIDADES_ACUMULADAS,
    baseOp + diasPasados * OPORTUNIDADES_POR_DIA
  );

  return {
    oportunidadesDisponibles: acumuladas,
    ultimoDiaOportunidadesSeg: ultimaMarca + diasPasados * SEGUNDOS_POR_DIA,
  };
};

export default function App() {
  const [cuentasRegistradas, setCuentasRegistradas] = useState([]);
  const [correoActivo, setCorreoActivo] = useState(null);

  const [modoRegistro, setModoRegistro] = useState(false);
  const [nombreInput, setNombreInput] = useState('');
  const [correoInput, setCorreoInput] = useState('');
  const [claveInput, setClaveInput] = useState('');
  const [confirmarClaveInput, setConfirmarClaveInput] = useState('');
  const [errorAuth, setErrorAuth] = useState('');

  const [temaKey, setTemaKey] = useState('rosado');
  const [pestanaActiva, setPestanaActiva] = useState('descubrir');
  const [indicePerfil, setIndicePerfil] = useState(0);
  const [notificaciones, setNotificaciones] = useState(true);
  const [modoIncognito, setModoIncognito] = useState(false);
  const [mostrarDistancia, setMostrarDistancia] = useState(true);

  const [bioInput, setBioInput] = useState('');
  const [editandoPerfil, setEditandoPerfil] = useState(false);
  const [nombrePerfilInput, setNombrePerfilInput] = useState('');

  const [chats, setChats] = useState(CHATS_INICIALES);
  const [chatAbiertoId, setChatAbiertoId] = useState(null);
  const [textoMensaje, setTextoMensaje] = useState('');

  const [grabandoAudio, setGrabandoAudio] = useState(false);
  const [segundosGrabacion, setSegundosGrabacion] = useState(0);
  const [audioReproduciendoId, setAudioReproduciendoId] = useState(null);

  const [ahoraSeg, setAhoraSeg] = useState(() => Math.floor(Date.now() / 1000));

  const [llamadaActiva, setLlamadaActiva] = useState(null);
  const [camaraFrontal, setCamaraFrontal] = useState(true);

  const [esperandoRecompensa, setEsperandoRecompensa] = useState(false);
  const [segundosEspera, setSegundosEspera] = useState(SEGUNDOS_ESPERA_OPORTUNIDAD);

  const tema = TEMAS[temaKey];
  const usuario = cuentasRegistradas.find((c) => c.correo === correoActivo) || null;
  const chatActivo = chats.find((c) => c.id === chatAbiertoId) || null;

  const accesorioEquipado =
    ACCESORIOS_PERFIL.find((a) => a.id === usuario?.accesorioEquipado) || ACCESORIOS_PERFIL[0];
  const filtroActivo =
    FILTROS_FOTO.find((f) => f.id === usuario?.filtroFoto) || FILTROS_FOTO[0];

  const actualizarUsuario = (transformador) => {
    if (!correoActivo) return;
    setCuentasRegistradas((prev) =>
      prev.map((c) => (c.correo === correoActivo ? transformador(c) : c))
    );
  };

  const descontarMonedas = (cantidad) => {
    if (!usuario || usuario.monedas < cantidad) return false;
    actualizarUsuario((c) => ({
      ...c,
      monedas: Math.max(0, c.monedas - cantidad),
    }));
    return true;
  };

  const usuarioRef = useRef(usuario);
  usuarioRef.current = usuario;

  const actualizarUsuarioRef = useRef(actualizarUsuario);
  actualizarUsuarioRef.current = actualizarUsuario;

  const descontarMonedasRef = useRef(descontarMonedas);
  descontarMonedasRef.current = descontarMonedas;

  const grabandoAudioRef = useRef(grabandoAudio);
  grabandoAudioRef.current = grabandoAudio;

  useEffect(() => {
    if (usuario) {
      setNombrePerfilInput(usuario.nombre);
      setBioInput(usuario.bio || '¡Hola! Nuevo en Amour, listo para conocer gente.');
    }
  }, [usuario]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Math.floor(Date.now() / 1000);
      setAhoraSeg(now);
      if (grabandoAudioRef.current) {
        setSegundosGrabacion((s) => s + 1);
      }
      setCuentasRegistradas((prev) =>
        prev.map((c) => ({
          ...c,
          ...calcularOportunidadesActualizadas(c, now),
        }))
      );
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!esperandoRecompensa) return;
    if (segundosEspera <= 0) {
      setEsperandoRecompensa(false);
      const now = Math.floor(Date.now() / 1000);
      actualizarUsuarioRef.current((c) => {
        const calc = calcularOportunidadesActualizadas(c, now);
        const disponibles = calc.oportunidadesDisponibles;
        if (disponibles <= 0) return c;
        return {
          ...c,
          oportunidadesDisponibles: disponibles - 1,
          ultimoDiaOportunidadesSeg: calc.ultimoDiaOportunidadesSeg,
          monedas: c.monedas + RECOMPENSA_POR_OPORTUNIDAD,
        };
      });
      Alert.alert(
        'Recompensa recibida',
        `Esperaste 10 segundos y ganaste +${RECOMPENSA_POR_OPORTUNIDAD} monedas.`
      );
      return;
    }

    const t = setTimeout(() => {
      setSegundosEspera((s) => s - 1);
    }, 1000);
    return () => clearTimeout(t);
  }, [esperandoRecompensa, segundosEspera]);

  const oportunidadesDisponibles = usuario
    ? calcularOportunidadesActualizadas(usuario, ahoraSeg).oportunidadesDisponibles
    : 0;

  const iniciarEspera10Segundos = () => {
    if (!usuario) return;
    if (oportunidadesDisponibles <= 0) {
      Alert.alert(
        'Sin oportunidades disponibles',
        `Mañana se sumarán +${OPORTUNIDADES_POR_DIA} nuevas oportunidades (acumula hasta ${MAX_OPORTUNIDADES_ACUMULADAS}).`
      );
      return;
    }
    setSegundosEspera(SEGUNDOS_ESPERA_OPORTUNIDAD);
    setEsperandoRecompensa(true);
  };

  const segundosRestantesCalendario = usuario?.finBloqueoCalendarioSeg
    ? Math.max(0, usuario.finBloqueoCalendarioSeg - ahoraSeg)
    : 0;

  const reclamarDiaCalendario = (indiceDia) => {
    if (!usuario) return;
    const diaActual = usuario.diaCalendarioActual || 0;

    if (indiceDia !== diaActual) {
      Alert.alert(
        'Orden del calendario',
        `Debes reclamar primero ${RECOMPENSAS_CALENDARIO[diaActual].dia} (${RECOMPENSAS_CALENDARIO[diaActual].monedas} monedas).`
      );
      return;
    }

    if (segundosRestantesCalendario > 0) {
      Alert.alert(
        'Espera 24 horas',
        `La siguiente recompensa se desbloquea en ${formatear24Horas(segundosRestantesCalendario)}.`
      );
      return;
    }

    const recompensa = RECOMPENSAS_CALENDARIO[indiceDia];
    const now = Math.floor(Date.now() / 1000);
    const siguienteDia = (indiceDia + 1) % RECOMPENSAS_CALENDARIO.length;

    actualizarUsuario((c) => ({
      ...c,
      monedas: c.monedas + recompensa.monedas,
      diaCalendarioActual: siguienteDia,
      finBloqueoCalendarioSeg: now + SEGUNDOS_POR_DIA,
    }));

    Alert.alert(
      `${recompensa.dia} reclamado`,
      `Ganaste +${recompensa.monedas.toLocaleString()} monedas. Próxima recompensa en 24 horas.`
    );
  };

  const agregarMensajeAChat = (chatId, nuevoMensaje, resumenUltimo) => {
    setChats((prev) =>
      prev.map((c) =>
        c.id === chatId
          ? {
              ...c,
              ultimoMensaje: resumenUltimo,
              hora: 'Ahora',
              noLeido: false,
              mensajes: [...c.mensajes, nuevoMensaje],
            }
          : c
      )
    );
  };

  const llamadaConectadaActiva = llamadaActiva?.estado === 'conectada';

  useEffect(() => {
    if (!llamadaConectadaActiva) return;

    const intervalo = setInterval(() => {
      setLlamadaActiva((actual) => {
        if (!actual || actual.estado !== 'conectada') return actual;
        const nuevosSegundos = actual.segundos + 1;
        const completoMinuto = nuevosSegundos % 60 === 0;

        if (completoMinuto) {
          const saldoActual = usuarioRef.current?.monedas ?? 0;
          if (saldoActual < COSTO_POR_MINUTO_LLAMADA) {
            Alert.alert(
              'Saldo insuficiente',
              `Se agotaron tus monedas para continuar el siguiente minuto (${COSTO_POR_MINUTO_LLAMADA} monedas/min).`
            );
            return null;
          }
          descontarMonedasRef.current(COSTO_POR_MINUTO_LLAMADA);
          return {
            ...actual,
            segundos: nuevosSegundos,
            monedasGastadas: actual.monedasGastadas + COSTO_POR_MINUTO_LLAMADA,
          };
        }

        return {
          ...actual,
          segundos: nuevosSegundos,
        };
      });
    }, 1000);

    return () => clearInterval(intervalo);
  }, [llamadaConectadaActiva]);

  const iniciarLlamada = (tipo, contacto) => {
    if (!usuario) return;
    if (usuario.monedas < COSTO_POR_MINUTO_LLAMADA) {
      Alert.alert(
        'Monedas insuficientes',
        `Necesitas al menos ${COSTO_POR_MINUTO_LLAMADA} monedas para iniciar el primer minuto.`,
        [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Ir a la Tienda', onPress: () => setPestanaActiva('tienda') },
        ]
      );
      return;
    }

    setLlamadaActiva({
      tipo,
      contacto,
      estado: 'timbrando',
      segundos: 0,
      monedasGastadas: 0,
    });
  };

  const aceptarLlamada = () => {
    if (!llamadaActiva) return;
    if (!descontarMonedas(COSTO_POR_MINUTO_LLAMADA)) return;
    setLlamadaActiva((actual) => ({
      ...actual,
      estado: 'conectada',
      segundos: 0,
      monedasGastadas: COSTO_POR_MINUTO_LLAMADA,
    }));
  };

  const rechazarLlamada = () => {
    if (!llamadaActiva) return;
    const etiqueta =
      llamadaActiva.tipo === 'video'
        ? 'Rechazo de videollamada'
        : 'Rechazo de llamada';
    const chatIdObjetivo = llamadaActiva.contacto?.id;
    setLlamadaActiva(null);

    if (chatIdObjetivo) {
      agregarMensajeAChat(
        chatIdObjetivo,
        {
          id: `rechazo_${Date.now()}`,
          autor: 'ellos',
          tipo: 'texto',
          texto: `📵 ${etiqueta}`,
          hora: 'Ahora',
        },
        etiqueta
      );
    }

    Alert.alert(etiqueta, `Se registró como ${etiqueta}.`);
  };

  const finalizarLlamada = () => {
    if (!llamadaActiva) return;
    const minutosExactos = Math.floor(llamadaActiva.segundos / 60);
    const tiempoFormateado = formatearReloj(llamadaActiva.segundos);
    const tipoTexto = llamadaActiva.tipo === 'video' ? 'videollamada' : 'llamada';
    const resumen = `Estuviste ${minutosExactos} ${
      minutosExactos === 1 ? 'minuto' : 'minutos'
    } (${tiempoFormateado}) en la ${tipoTexto}. Total cobrado: ${llamadaActiva.monedasGastadas} monedas.`;

    const chatIdObjetivo = llamadaActiva.contacto?.id;
    setLlamadaActiva(null);

    if (chatIdObjetivo) {
      agregarMensajeAChat(
        chatIdObjetivo,
        {
          id: `fin_llamada_${Date.now()}`,
          autor: 'yo',
          tipo: 'texto',
          texto: `⏱️ ${tipoTexto.toUpperCase()} finalizada · ${minutosExactos} min (${tiempoFormateado})`,
          hora: 'Ahora',
        },
        `${minutosExactos} min en ${tipoTexto}`
      );
    }

    Alert.alert('Llamada finalizada', resumen);
  };

  const abrirChatConUsuario = (persona) => {
    const idChat = `chat_${persona.correo || persona.id}`;
    setChats((prev) => {
      const existe = prev.some((c) => c.id === idChat || c.correo === persona.correo);
      if (existe) return prev;
      return [
        {
          id: idChat,
          correo: persona.correo,
          nombre: persona.nombre,
          ultimoMensaje: '¡Hola! Acabo de ver tu perfil.',
          hora: 'Ahora',
          noLeido: false,
          avatar: persona.imagen || persona.foto,
          mensajes: [
            {
              id: `saludo_${Date.now()}`,
              autor: 'ellos',
              tipo: 'texto',
              texto: `¡Hola ${persona.nombre}! Qué gusto saludarte.`,
              hora: 'Ahora',
            },
          ],
        },
        ...prev,
      ];
    });
    const encontrado = chats.find((c) => c.id === idChat || c.correo === persona.correo);
    setChatAbiertoId(encontrado ? encontrado.id : idChat);
    setPestanaActiva('chats');
  };

  const enviarTexto = () => {
    if (!chatActivo || !textoMensaje.trim()) return;
    const contenido = textoMensaje.trim();
    agregarMensajeAChat(
      chatActivo.id,
      {
        id: String(Date.now()),
        autor: 'yo',
        tipo: 'texto',
        texto: contenido,
        hora: 'Ahora',
      },
      contenido
    );
    setTextoMensaje('');
  };

  const enviarFotoDesdeGaleria = () => {
    if (!chatActivo) return;
    if (usuario.monedas < COSTO_MULTIMEDIA) {
      Alert.alert('Monedas insuficientes', `Enviar una foto cuesta ${COSTO_MULTIMEDIA} monedas.`);
      return;
    }
    if (!descontarMonedas(COSTO_MULTIMEDIA)) return;

    const fotoElegida =
      FOTOS_MUESTRA_GALERIA[Math.floor(Math.random() * FOTOS_MUESTRA_GALERIA.length)];

    agregarMensajeAChat(
      chatActivo.id,
      {
        id: String(Date.now()),
        autor: 'yo',
        tipo: 'imagen',
        imagen: fotoElegida,
        hora: 'Ahora',
      },
      '📷 Foto enviada'
    );
  };

  const iniciarGrabacionNota = () => {
    if (!chatActivo) return;
    if (usuario.monedas < COSTO_MULTIMEDIA) {
      Alert.alert('Monedas insuficientes', `Enviar una nota cuesta ${COSTO_MULTIMEDIA} monedas.`);
      return;
    }
    setSegundosGrabacion(0);
    setGrabandoAudio(true);
  };

  const detenerYEnviarNota = () => {
    if (!chatActivo) {
      setGrabandoAudio(false);
      return;
    }
    const duracionFinal = formatearReloj(Math.max(1, segundosGrabacion));
    setGrabandoAudio(false);
    setSegundosGrabacion(0);

    if (!descontarMonedas(COSTO_MULTIMEDIA)) return;

    agregarMensajeAChat(
      chatActivo.id,
      {
        id: String(Date.now()),
        autor: 'yo',
        tipo: 'audio',
        duracion: duracionFinal,
        hora: 'Ahora',
      },
      `🎤 Nota (${duracionFinal})`
    );
  };

  const reproducirNota = (msg) => {
    setAudioReproduciendoId(msg.id);
    setTimeout(() => {
      setAudioReproduciendoId((actual) => (actual === msg.id ? null : actual));
    }, 2500);
  };

  const cambiarFotoPrincipalMuestra = () => {
    const siguienteFoto =
      FOTOS_MUESTRA_GALERIA[Math.floor(Math.random() * FOTOS_MUESTRA_GALERIA.length)];
    actualizarUsuario((c) => ({ ...c, foto: siguienteFoto }));
  };

  const agregarFotoIlimitadaPerfil = () => {
    const nuevaFoto =
      FOTOS_MUESTRA_GALERIA[Math.floor(Math.random() * FOTOS_MUESTRA_GALERIA.length)];
    actualizarUsuario((c) => ({
      ...c,
      galeriaExtra: [...(c.galeriaExtra || []), nuevaFoto],
    }));
  };

  const eliminarFotoExtra = (indexAEliminar) => {
    actualizarUsuario((c) => ({
      ...c,
      galeriaExtra: (c.galeriaExtra || []).filter((_, idx) => idx !== indexAEliminar),
    }));
  };

  const guardarDatosPerfil = () => {
    const limpioNombre = nombrePerfilInput.trim();
    if (!limpioNombre) {
      Alert.alert('Nombre vacío', 'Escribe un nombre para tu perfil.');
      return;
    }
    actualizarUsuario((c) => ({
      ...c,
      nombre: limpioNombre,
      bio: bioInput.trim(),
    }));
    setEditandoPerfil(false);
    Alert.alert('Perfil actualizado', 'Tus cambios se guardaron.');
  };

  const comprarOEquiparAccesorio = (accesorio) => {
    if (!usuario) return;
    const yaComprado = usuario.accesoriosComprados.includes(accesorio.id);

    if (yaComprado) {
      actualizarUsuario((c) => ({ ...c, accesorioEquipado: accesorio.id }));
      Alert.alert('Accesorio equipado', `Ahora luces "${accesorio.nombre}" en tu perfil.`);
      return;
    }

    if (usuario.monedas < accesorio.precio) {
      Alert.alert(
        'Monedas insuficientes',
        `Este accesorio cuesta ${accesorio.precio.toLocaleString()} monedas.`
      );
      return;
    }

    actualizarUsuario((c) => ({
      ...c,
      monedas: c.monedas - accesorio.precio,
      accesoriosComprados: [...c.accesoriosComprados, accesorio.id],
      accesorioEquipado: accesorio.id,
    }));

    Alert.alert(
      'Accesorio desbloqueado',
      `Compraste y equipaste "${accesorio.nombre}" por ${accesorio.precio.toLocaleString()} monedas.`
    );
  };

  const borrarCuentaActiva = () => {
    if (!usuario) return;
    Alert.alert(
      'Borrar cuenta',
      `¿Seguro que deseas borrar permanentemente la cuenta ${usuario.correo}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Borrar cuenta',
          style: 'destructive',
          onPress: () => {
            const correoABorrar = usuario.correo;
            setLlamadaActiva(null);
            setChatAbiertoId(null);
            setCorreoActivo(null);
            setPestanaActiva('descubrir');
            setCuentasRegistradas((prev) => prev.filter((c) => c.correo !== correoABorrar));
            Alert.alert('Cuenta borrada', 'La cuenta ha sido eliminada.');
          },
        },
      ]
    );
  };

  const limpiarCampos = () => {
    setNombreInput('');
    setCorreoInput('');
    setClaveInput('');
    setConfirmarClaveInput('');
    setErrorAuth('');
  };

  const manejarCrearCuenta = () => {
    const nombre = nombreInput.trim();
    const correo = correoInput.trim().toLowerCase();
    const clave = claveInput.trim();

    if (!nombre || !correo || !clave) {
      setErrorAuth('Completa todos los campos para crear tu cuenta.');
      return;
    }
    if (!correo.includes('@') || !correo.includes('.')) {
      setErrorAuth('Ingresa una dirección de correo válida (ej. tunombre@gmail.com).');
      return;
    }
    if (clave.length < 4) {
      setErrorAuth('La contraseña debe tener al menos 4 caracteres.');
      return;
    }
    if (clave !== confirmarClaveInput.trim()) {
      setErrorAuth('Las contraseñas no coinciden.');
      return;
    }

    const yaExiste = cuentasRegistradas.some((c) => c.correo === correo);
    if (yaExiste) {
      setErrorAuth('Ese correo ya tiene una cuenta creada. Cambia a "Iniciar sesión".');
      return;
    }

    const now = Math.floor(Date.now() / 1000);
    const nuevaCuenta = {
      nombre,
      correo,
      clave,
      bio: '¡Hola! Nuevo en Amour, listo para conocer gente.',
      monedas: 0,
      foto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      galeriaExtra: [],
      filtroFoto: 'normal',
      accesoriosComprados: ['acc_ninguno'],
      accesorioEquipado: 'acc_ninguno',
      diaCalendarioActual: 0,
      finBloqueoCalendarioSeg: 0,
      oportunidadesDisponibles: OPORTUNIDADES_POR_DIA,
      ultimoDiaOportunidadesSeg: now,
    };

    setCuentasRegistradas((prev) => [...prev, nuevaCuenta]);
    setCorreoActivo(correo);
    limpiarCampos();
  };

  const manejarIniciarSesion = () => {
    const correo = correoInput.trim().toLowerCase();
    const clave = claveInput.trim();

    if (!correo || !clave) {
      setErrorAuth('Escribe tu correo Gmail y contraseña.');
      return;
    }

    const cuentaEncontrada = cuentasRegistradas.find((c) => c.correo === correo);
    if (!cuentaEncontrada) {
      setErrorAuth('No encontramos una cuenta con ese correo. Pulsa "Crear cuenta" primero.');
      return;
    }
    if (cuentaEncontrada.clave !== clave) {
      setErrorAuth('Contraseña incorrecta.');
      return;
    }

    setCorreoActivo(cuentaEncontrada.correo);
    limpiarCampos();
  };

  const entrarConCuentaRapida = (correo) => {
    setCorreoActivo(correo);
    limpiarCampos();
  };

  const cerrarSesion = () => {
    setLlamadaActiva(null);
    setChatAbiertoId(null);
    setCorreoActivo(null);
    setPestanaActiva('descubrir');
  };

  if (!usuario) {
    return (
      <SafeAreaView style={[styles.loginContainer, { backgroundColor: tema.loginFondo }]}>
        <StatusBar barStyle="light-content" backgroundColor={tema.loginFondo} />
        <View style={[styles.loginGlowTop, { backgroundColor: tema.loginAcento }]} />

        <ScrollView contentContainerStyle={styles.loginScroll} showsVerticalScrollIndicator={false}>
          <View style={styles.logoCircle}>
            <Text style={[styles.heartIcon, { color: tema.primario }]}>♥</Text>
          </View>
          <Text style={styles.appTitle}>Amour</Text>
          <Text style={styles.appSubtitle}>
            Es totalmente seguro: nadie va a agarrar tu privacidad ni tus datos. Totalmente gratuito para que lo disfrutes.
          </Text>

          <View style={styles.authSwitchRow}>
            <TouchableOpacity
              style={[styles.authTab, !modoRegistro && styles.authTabActive]}
              onPress={() => {
                setModoRegistro(false);
                setErrorAuth('');
              }}
            >
              <Text style={[styles.authTabText, !modoRegistro && { color: tema.primario, fontWeight: '800' }]}>
                Iniciar sesión
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.authTab, modoRegistro && styles.authTabActive]}
              onPress={() => {
                setModoRegistro(true);
                setErrorAuth('');
              }}
            >
              <Text style={[styles.authTabText, modoRegistro && { color: tema.primario, fontWeight: '800' }]}>
                Crear cuenta
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.emailBox}>
            {errorAuth ? (
              <View style={styles.errorBanner}>
                <Text style={styles.errorBannerText}>{errorAuth}</Text>
              </View>
            ) : null}

            {modoRegistro && (
              <TextInput
                placeholder="Tu nombre o apodo"
                placeholderTextColor="#888"
                value={nombreInput}
                onChangeText={setNombreInput}
                style={styles.authInput}
              />
            )}

            <TextInput
              placeholder="Tu correo Gmail (ej. usuario@gmail.com)"
              placeholderTextColor="#888"
              keyboardType="email-address"
              autoCapitalize="none"
              value={correoInput}
              onChangeText={setCorreoInput}
              style={styles.authInput}
            />

            <TextInput
              placeholder="Contraseña"
              placeholderTextColor="#888"
              secureTextEntry
              value={claveInput}
              onChangeText={setClaveInput}
              style={styles.authInput}
            />

            {modoRegistro && (
              <TextInput
                placeholder="Confirmar contraseña"
                placeholderTextColor="#888"
                secureTextEntry
                value={confirmarClaveInput}
                onChangeText={setConfirmarClaveInput}
                style={styles.authInput}
              />
            )}

            <TouchableOpacity
              style={[styles.submitEmailBtn, { backgroundColor: tema.primario }]}
              onPress={modoRegistro ? manejarCrearCuenta : manejarIniciarSesion}
            >
              <Text style={styles.submitEmailText}>
                {modoRegistro ? 'Crear mi cuenta ahora' : 'Entrar a mi cuenta'}
              </Text>
            </TouchableOpacity>
          </View>

          {cuentasRegistradas.length > 0 && (
            <View style={styles.savedAccountsBox}>
              <Text style={styles.savedAccountsTitle}>Cuentas registradas en este dispositivo:</Text>
              {cuentasRegistradas.map((cuenta) => (
                <TouchableOpacity
                  key={cuenta.correo}
                  style={styles.savedAccountRow}
                  onPress={() => entrarConCuentaRapida(cuenta.correo)}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={styles.savedAccountName}>{cuenta.nombre}</Text>
                    <Text style={styles.savedAccountEmail}>{cuenta.correo}</Text>
                  </View>
                  <View style={styles.savedCoinsPill}>
                    <Text style={styles.savedCoinsText}>🪙 {cuenta.monedas.toLocaleString()}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (llamadaActiva) {
    const esVideo = llamadaActiva.tipo === 'video';
    const estaConectada = llamadaActiva.estado === 'conectada';
    const minutosTranscurridos = Math.floor(llamadaActiva.segundos / 60);

    return (
      <SafeAreaView style={styles.callScreen}>
        <StatusBar barStyle="light-content" backgroundColor="#121216" />

        <View style={styles.callOverlayLayer}>
          <View style={styles.callTopInfo}>
            <Text style={styles.callBadge}>
              {esVideo
                ? estaConectada
                  ? '📹 VIDEOLLAMADA EN CURSO'
                  : '📹 VIDEOLLAMADA'
                : estaConectada
                ? '📞 LLAMADA EN CURSO'
                : '📞 LLAMADA DE VOZ'}
            </Text>
            <Text style={styles.callRateText}>
              Tarifa: {COSTO_POR_MINUTO_LLAMADA} monedas por cada minuto
            </Text>
          </View>

          <View style={styles.callCenter}>
            <Image
              source={{ uri: llamadaActiva.contacto.avatar }}
              style={[styles.callAvatar, { borderColor: tema.primario }]}
            />
            <Text style={styles.callName}>{llamadaActiva.contacto.nombre}</Text>

            {estaConectada ? (
              <>
                <Text style={styles.callTimer}>{formatearReloj(llamadaActiva.segundos)}</Text>
                <Text style={styles.minutesCounterBadge}>
                  Minutos en llamada: {minutosTranscurridos} min
                </Text>

                <View style={styles.callBillingCard}>
                  <Text style={styles.callBillingLine}>
                    Cobrado en esta sesión:{' '}
                    <Text style={styles.callHighlight}>{llamadaActiva.monedasGastadas} monedas</Text>
                  </Text>
                  <Text style={styles.callBillingLine}>
                    Saldo restante:{' '}
                    <Text style={styles.callHighlight}>🪙 {usuario.monedas.toLocaleString()}</Text>
                  </Text>
                </View>
              </>
            ) : (
              <Text style={styles.ringingStatusText}>
                Elige si deseas aceptar o rechazar la {esVideo ? 'videollamada' : 'llamada'}.
              </Text>
            )}
          </View>

          {!estaConectada ? (
            <View style={styles.callBottomRow}>
              <TouchableOpacity
                style={[styles.hangupBtn, { flex: 1 }]}
                onPress={rechazarLlamada}
              >
                <Text style={styles.hangupText}>✕  Rechazar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.acceptCallBtn, { flex: 1 }]}
                onPress={aceptarLlamada}
              >
                <Text style={styles.hangupText}>✓  Aceptar</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.callBottomRow}>
              {esVideo && (
                <TouchableOpacity
                  style={styles.flipCamBtn}
                  onPress={() => setCamaraFrontal((f) => !f)}
                >
                  <Text style={styles.flipCamText}>
                    {camaraFrontal ? '🔄 Frontal' : '🔄 Trasera'}
                  </Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity
                style={[styles.hangupBtn, { flex: 1 }]}
                onPress={finalizarLlamada}
              >
                <Text style={styles.hangupText}>✕  Finalizar</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </SafeAreaView>
    );
  }

  const otrosUsuariosRegistrados = cuentasRegistradas
    .filter((c) => c.correo !== usuario.correo)
    .map((c, idx) => ({
      id: `user_${c.correo}_${idx}`,
      correo: c.correo,
      nombre: c.nombre,
      edad: 23 + (idx % 6),
      distancia: 'Usuario registrado',
      bio: c.bio || '¡Hola! Nuevo usuario en Amour.',
      imagen: c.foto,
    }));

  const comunidadDescubrir = [...otrosUsuariosRegistrados, ...PERFILES_BASE];
  const perfilActual = comunidadDescubrir[indicePerfil % comunidadDescubrir.length];

  const siguientePerfil = () => {
    setIndicePerfil((prev) => (prev + 1) % comunidadDescubrir.length);
  };

  const renderAvatarConFiltroYMarco = (size = 76) => (
    <View
      style={[
        styles.avatarFilterWrapper,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor:
            accesorioEquipado.id !== 'acc_ninguno'
              ? accesorioEquipado.colorMarco
              : filtroActivo.marcoExtra !== 'transparent'
              ? filtroActivo.marcoExtra
              : tema.borde,
          borderWidth: accesorioEquipado.id !== 'acc_ninguno' ? 3.5 : 2,
        },
      ]}
    >
      <Image
        source={{ uri: usuario.foto }}
        style={{ width: '100%', height: '100%', borderRadius: size / 2 }}
      />
      {filtroActivo.overlayColor !== 'transparent' && (
        <View
          pointerEvents="none"
          style={[
            StyleSheet.absoluteFillObject,
            { backgroundColor: filtroActivo.overlayColor, borderRadius: size / 2 },
          ]}
        />
      )}
    </View>
  );

  const renderOportunidades150Monedas = () => (
    <View
      style={[
        styles.adsBox,
        { backgroundColor: tema.tarjeta, borderColor: tema.borde },
      ]}
    >
      <View style={styles.calendarTopRow}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.calendarTitle, { color: tema.texto }]}>
            🪙 Ganar {RECOMPENSA_POR_OPORTUNIDAD} Monedas ({SEGUNDOS_ESPERA_OPORTUNIDAD}s)
          </Text>
          <Text style={[styles.calendarSub, { color: tema.subtexto }]}>
            Disponibles: {oportunidadesDisponibles} (500/día · acumula hasta {MAX_OPORTUNIDADES_ACUMULADAS})
          </Text>
        </View>
        <View style={[styles.timerPill, { backgroundColor: tema.secundario }]}>
          <Text style={[styles.timerPillText, { color: tema.primario }]}>
            {oportunidadesDisponibles} disp.
          </Text>
        </View>
      </View>

      <TouchableOpacity
        style={[
          styles.watchAdBtn,
          {
            backgroundColor: oportunidadesDisponibles > 0 ? tema.primario : tema.secundario,
          },
        ]}
        onPress={iniciarEspera10Segundos}
      >
        <Text
          style={[
            styles.watchAdBtnText,
            { color: oportunidadesDisponibles > 0 ? '#FFFFFF' : tema.primario },
          ]}
        >
          {oportunidadesDisponibles > 0
            ? `Esperar ${SEGUNDOS_ESPERA_OPORTUNIDAD}s para ganar +${RECOMPENSA_POR_OPORTUNIDAD} monedas`
            : `Sin oportunidades hoy · Mañana se suman +${OPORTUNIDADES_POR_DIA}`}
        </Text>
      </TouchableOpacity>
    </View>
  );

  const renderCalendarioSemanal = () => (
    <View
      style={[
        styles.calendarCard,
        { backgroundColor: tema.tarjeta, borderColor: tema.borde },
      ]}
    >
      <View style={styles.calendarTopRow}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.calendarTitle, { color: tema.texto }]}>
            📅 Calendario Semanal (24h)
          </Text>
          <Text style={[styles.calendarSub, { color: tema.subtexto }]}>
            {segundosRestantesCalendario > 0
              ? `Siguiente día en: ${formatear24Horas(segundosRestantesCalendario)}`
              : `Disponible hoy: ${RECOMPENSAS_CALENDARIO[usuario.diaCalendarioActual || 0].dia} (+${RECOMPENSAS_CALENDARIO[usuario.diaCalendarioActual || 0].monedas})`}
          </Text>
        </View>
        <View style={[styles.timerPill, { backgroundColor: tema.secundario }]}>
          <Text style={[styles.timerPillText, { color: tema.primario }]}>
            {formatear24Horas(segundosRestantesCalendario)}
          </Text>
        </View>
      </View>

      <View style={styles.daysRow}>
        {RECOMPENSAS_CALENDARIO.map((item, idx) => {
          const esActual = idx === (usuario.diaCalendarioActual || 0);
          const reclamado = idx < (usuario.diaCalendarioActual || 0);
          return (
            <TouchableOpacity
              key={item.dia}
              onPress={() => reclamarDiaCalendario(idx)}
              style={[
                styles.dayChip,
                {
                  backgroundColor: reclamado
                    ? tema.secundario
                    : esActual
                    ? tema.primario
                    : tema.fondo,
                  borderColor: esActual ? tema.primario : tema.borde,
                  opacity: reclamado ? 0.75 : 1,
                },
              ]}
            >
              <Text
                style={[
                  styles.dayLabel,
                  { color: esActual ? '#FFFFFF' : tema.texto },
                ]}
              >
                {item.dia}
              </Text>
              <Text
                style={[
                  styles.dayReward,
                  { color: esActual ? '#FFE5EC' : tema.primario },
                ]}
              >
                {reclamado ? '✓' : item.monedas}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const renderContenido = () => {
    if (pestanaActiva === 'descubrir') {
      return (
        <View style={styles.discoverContainer}>
          <View style={[styles.card, { backgroundColor: tema.tarjeta }]}>
            <Image source={{ uri: perfilActual.imagen }} style={styles.cardImage} />
            <View style={styles.cardOverlay}>
              <Text style={styles.cardName}>
                {perfilActual.nombre}, <Text style={styles.cardAge}>{perfilActual.edad}</Text>
              </Text>
              <Text style={styles.cardDistance}>📍 {perfilActual.distancia}</Text>
              <Text style={styles.cardBio}>{perfilActual.bio}</Text>

              <TouchableOpacity
                style={[styles.greetBtn, { backgroundColor: tema.primario }]}
                onPress={() => abrirChatConUsuario(perfilActual)}
              >
                <Text style={styles.greetBtnText}>💬 Saludar y escribir a {perfilActual.nombre}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.circleBtn, styles.passBtn, { backgroundColor: tema.tarjeta }]}
              onPress={siguientePerfil}
            >
              <Text style={[styles.passText, { color: tema.primario }]}>✕</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.circleBtn, styles.starBtn, { backgroundColor: tema.tarjeta }]}
              onPress={() => abrirChatConUsuario(perfilActual)}
            >
              <Text style={styles.starText}>💬</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.circleBtn, styles.likeBtn, { backgroundColor: tema.primario }]}
              onPress={siguientePerfil}
            >
              <Text style={styles.likeText}>♥</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }

    if (pestanaActiva === 'chats') {
      if (chatActivo) {
        return (
          <View style={styles.chatRoomContainer}>
            <View
              style={[
                styles.chatRoomHeader,
                { backgroundColor: tema.tarjeta, borderColor: tema.borde },
              ]}
            >
              <TouchableOpacity
                style={[styles.backBtn, { backgroundColor: tema.secundario }]}
                onPress={() => {
                  setGrabandoAudio(false);
                  setChatAbiertoId(null);
                }}
              >
                <Text style={[styles.backBtnText, { color: tema.primario }]}>←</Text>
              </TouchableOpacity>

              <Image source={{ uri: chatActivo.avatar }} style={styles.chatRoomAvatar} />

              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={[styles.chatName, { color: tema.texto }]}>{chatActivo.nombre}</Text>
                <Text style={[styles.chatRateHint, { color: tema.subtexto }]}>
                  Llamada/Video: {COSTO_POR_MINUTO_LLAMADA} mon/min
                </Text>
              </View>

              <TouchableOpacity
                style={[styles.callActionPill, { backgroundColor: tema.secundario }]}
                onPress={() => iniciarLlamada('voz', chatActivo)}
              >
                <Text style={[styles.callActionText, { color: tema.primario }]}>📞</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.callActionPill, { backgroundColor: tema.primario }]}
                onPress={() => iniciarLlamada('video', chatActivo)}
              >
                <Text style={styles.callActionTextWhite}>📹</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.messagesList} showsVerticalScrollIndicator={false}>
              {chatActivo.mensajes.map((msg) => {
                const esMio = msg.autor === 'yo';
                const reproduciendo = audioReproduciendoId === msg.id;
                return (
                  <View
                    key={msg.id}
                    style={[
                      styles.bubble,
                      esMio
                        ? [styles.bubbleMine, { backgroundColor: tema.primario }]
                        : [
                            styles.bubbleTheirs,
                            { backgroundColor: tema.tarjeta, borderColor: tema.borde },
                          ],
                    ]}
                  >
                    {msg.tipo === 'texto' && (
                      <Text style={[styles.bubbleText, { color: esMio ? '#FFFFFF' : tema.texto }]}>
                        {msg.texto}
                      </Text>
                    )}

                    {msg.tipo === 'imagen' && (
                      <View>
                        <Image source={{ uri: msg.imagen }} style={styles.msgPhoto} />
                        <Text
                          style={[
                            styles.msgMeta,
                            { color: esMio ? '#FFE5EC' : tema.subtexto },
                          ]}
                        >
                          Foto · {COSTO_MULTIMEDIA} monedas
                        </Text>
                      </View>
                    )}

                    {msg.tipo === 'audio' && (
                      <TouchableOpacity
                        onPress={() => reproducirNota(msg)}
                        style={styles.audioBubbleRow}
                      >
                        <Text
                          style={[
                            styles.bubbleText,
                            { color: esMio ? '#FFFFFF' : tema.texto, fontWeight: '700' },
                          ]}
                        >
                          {reproduciendo ? '🔊 Reproduciendo...' : `▶ Nota (${msg.duracion})`}
                        </Text>
                        <Text
                          style={[
                            styles.msgMeta,
                            { color: esMio ? '#FFE5EC' : tema.subtexto },
                          ]}
                        >
                          Toca para escuchar · {COSTO_MULTIMEDIA} monedas
                        </Text>
                      </TouchableOpacity>
                    )}

                    <Text
                      style={[
                        styles.bubbleTime,
                        { color: esMio ? 'rgba(255,255,255,0.8)' : tema.subtexto },
                      ]}
                    >
                      {msg.hora}
                    </Text>
                  </View>
                );
              })}
            </ScrollView>

            <View
              style={[
                styles.composerBox,
                { backgroundColor: tema.tarjeta, borderTopColor: tema.borde },
              ]}
            >
              <View style={styles.mediaToolsRow}>
                <TouchableOpacity
                  style={[styles.mediaChip, { backgroundColor: tema.secundario }]}
                  onPress={enviarFotoDesdeGaleria}
                >
                  <Text style={[styles.mediaChipText, { color: tema.primario }]}>
                    🖼️ Foto ({COSTO_MULTIMEDIA} mon)
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.mediaChip,
                    { backgroundColor: grabandoAudio ? '#E11D48' : tema.secundario },
                  ]}
                  onPress={grabandoAudio ? detenerYEnviarNota : iniciarGrabacionNota}
                >
                  <Text
                    style={[
                      styles.mediaChipText,
                      { color: grabandoAudio ? '#FFFFFF' : tema.primario },
                    ]}
                  >
                    {grabandoAudio
                      ? `⏹ Enviar (${formatearReloj(segundosGrabacion)})`
                      : `🎤 Nota (${COSTO_MULTIMEDIA} mon)`}
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={styles.textSendRow}>
                <TextInput
                  placeholder="Escribe un saludo o mensaje..."
                  placeholderTextColor={tema.subtexto}
                  value={textoMensaje}
                  onChangeText={setTextoMensaje}
                  style={[
                    styles.messageInput,
                    { backgroundColor: tema.fondo, color: tema.texto, borderColor: tema.borde },
                  ]}
                />
                <TouchableOpacity
                  style={[styles.sendBtn, { backgroundColor: tema.primario }]}
                  onPress={enviarTexto}
                >
                  <Text style={styles.sendBtnText}>➤</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        );
      }

      return (
        <ScrollView style={styles.sectionContainer} showsVerticalScrollIndicator={false}>
          <Text style={[styles.sectionTitle, { color: tema.texto }]}>Comunidad y Chats</Text>

          <Text style={[styles.subHeader, { color: tema.subtexto }]}>
            Usuarios registrados (toca para saludar)
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.matchesScroll}>
            {comunidadDescubrir.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={styles.matchAvatarContainer}
                onPress={() => abrirChatConUsuario(item)}
              >
                <Image
                  source={{ uri: item.imagen }}
                  style={[styles.matchAvatar, { borderColor: tema.primario }]}
                />
                <Text style={[styles.matchName, { color: tema.texto }]}>{item.nombre}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <Text style={[styles.subHeader, { color: tema.subtexto }]}>Conversaciones</Text>
          {chats.map((chat) => (
            <TouchableOpacity
              key={chat.id}
              onPress={() => setChatAbiertoId(chat.id)}
              style={[
                styles.chatRow,
                { backgroundColor: tema.tarjeta, borderColor: tema.borde },
              ]}
            >
              <Image source={{ uri: chat.avatar }} style={styles.chatAvatar} />
              <View style={styles.chatTextContainer}>
                <View style={styles.chatHeaderRow}>
                  <Text style={[styles.chatName, { color: tema.texto }]}>{chat.nombre}</Text>
                  <Text style={[styles.chatTime, { color: tema.subtexto }]}>{chat.hora}</Text>
                </View>
                <Text
                  style={[
                    styles.chatMessage,
                    { color: chat.noLeido ? tema.texto : tema.subtexto },
                    chat.noLeido && styles.chatMessageUnread,
                  ]}
                  numberOfLines={1}
                >
                  {chat.ultimoMensaje}
                </Text>
              </View>
              {chat.noLeido && (
                <View style={[styles.unreadDot, { backgroundColor: tema.primario }]} />
              )}
            </TouchableOpacity>
          ))}
        </ScrollView>
      );
    }

    if (pestanaActiva === 'tienda') {
      return (
        <ScrollView style={styles.sectionContainer} showsVerticalScrollIndicator={false}>
          <View style={styles.storeHeaderRow}>
            <Text style={[styles.sectionTitle, { color: tema.texto, marginTop: 0, marginBottom: 0 }]}>
              🛍️ Tienda de Monedas y Accesorios
            </Text>
            <View
              style={[
                styles.balanceBadge,
                { backgroundColor: tema.tarjeta, borderColor: tema.borde },
              ]}
            >
              <Text style={[styles.balanceText, { color: tema.texto }]}>
                🪙 {usuario.monedas.toLocaleString()}
              </Text>
            </View>
          </View>

          {renderOportunidades150Monedas()}
          {renderCalendarioSemanal()}

          <Text style={[styles.sectionTitle, { color: tema.texto }]}>
            Accesorios ({ACCESORIOS_PERFIL.length} · hasta 5,000 🪙)
          </Text>
          {ACCESORIOS_PERFIL.map((acc) => {
            const comprado = usuario.accesoriosComprados.includes(acc.id);
            const equipado = usuario.accesorioEquipado === acc.id;

            return (
              <View
                key={acc.id}
                style={[
                  styles.accessoryCard,
                  {
                    backgroundColor: tema.tarjeta,
                    borderColor: equipado ? acc.colorMarco : tema.borde,
                  },
                ]}
              >
                <View style={[styles.accessoryPreviewCircle, { borderColor: acc.colorMarco }]}>
                  <Text style={[styles.accessoryPreviewGlyph, { color: acc.colorMarco }]}>✦</Text>
                </View>

                <View style={{ flex: 1, marginHorizontal: 12 }}>
                  <View style={styles.accessoryTitleRow}>
                    <Text style={[styles.accessoryName, { color: tema.texto }]}>{acc.nombre}</Text>
                    <View style={[styles.badgePill, { backgroundColor: tema.secundario }]}>
                      <Text style={[styles.badgePillText, { color: tema.primario }]}>{acc.insignia}</Text>
                    </View>
                  </View>
                  <Text style={[styles.accessoryDesc, { color: tema.subtexto }]}>{acc.descripcion}</Text>
                </View>

                <TouchableOpacity
                  style={[
                    styles.accessoryActionBtn,
                    { backgroundColor: equipado ? tema.secundario : tema.primario },
                  ]}
                  onPress={() => comprarOEquiparAccesorio(acc)}
                >
                  <Text
                    style={[
                      styles.accessoryActionText,
                      { color: equipado ? tema.primario : '#FFFFFF' },
                    ]}
                  >
                    {equipado
                      ? 'Equipado'
                      : comprado
                      ? 'Usar'
                      : acc.precio === 0
                      ? 'Gratis'
                      : `🪙 ${acc.precio.toLocaleString()}`}
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })}

          <View style={{ height: 24 }} />
        </ScrollView>
      );
    }

    if (pestanaActiva === 'ajustes') {
      return (
        <ScrollView style={styles.sectionContainer} showsVerticalScrollIndicator={false}>
          <View style={styles.storeHeaderRow}>
            <TouchableOpacity
              style={[styles.backBtn, { backgroundColor: tema.secundario }]}
              onPress={() => setPestanaActiva('perfil')}
            >
              <Text style={[styles.backBtnText, { color: tema.primario }]}>← Perfil</Text>
            </TouchableOpacity>
            <Text style={[styles.sectionTitle, { color: tema.texto, marginTop: 0, marginBottom: 0 }]}>
              ⚙️ Ajustes
            </Text>
          </View>

          <View
            style={[
              styles.safetyInfoCard,
              { backgroundColor: tema.tarjeta, borderColor: tema.borde },
            ]}
          >
            <Text style={[styles.safetyTitle, { color: tema.texto }]}>
              🛡️ Seguridad, Privacidad y Gratuidad
            </Text>
            <Text style={[styles.safetyText, { color: tema.subtexto }]}>
              Es totalmente seguro: nadie va a agarrar tu privacidad ni tus datos, y es totalmente gratuito para que lo disfrutes.
            </Text>
          </View>

          <Text style={[styles.subHeader, { color: tema.subtexto }]}>Tema de Color</Text>
          <View
            style={[
              styles.themeBox,
              { backgroundColor: tema.tarjeta, borderColor: tema.borde },
            ]}
          >
            {Object.keys(TEMAS).map((key) => {
              const itemTema = TEMAS[key];
              const activo = temaKey === key;
              return (
                <TouchableOpacity
                  key={key}
                  onPress={() => setTemaKey(key)}
                  style={[
                    styles.themeOption,
                    {
                      borderColor: activo ? tema.primario : tema.borde,
                      backgroundColor: activo ? tema.secundario : 'transparent',
                    },
                  ]}
                >
                  <View
                    style={[
                      styles.colorCircle,
                      {
                        backgroundColor: itemTema.muestra,
                        borderColor: key === 'blanco' ? '#CCCCCC' : itemTema.muestra,
                      },
                    ]}
                  />
                  <Text style={[styles.themeLabel, { color: activo ? tema.primario : tema.texto }]}>
                    {itemTema.nombre}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          <Text style={[styles.subHeader, { color: tema.subtexto }]}>Preferencias de Cuenta</Text>
          <View
            style={[
              styles.settingsBox,
              { backgroundColor: tema.tarjeta, borderColor: tema.borde },
            ]}
          >
            <View style={styles.settingItem}>
              <Text style={[styles.settingText, { color: tema.texto }]}>🔔  Notificaciones de Matches</Text>
              <Switch
                value={notificaciones}
                onValueChange={setNotificaciones}
                trackColor={{ false: '#999999', true: tema.primario }}
                thumbColor="#FFFFFF"
              />
            </View>

            <View style={[styles.divider, { backgroundColor: tema.borde }]} />

            <View style={styles.settingItem}>
              <Text style={[styles.settingText, { color: tema.texto }]}>🕶️  Modo Incógnito</Text>
              <Switch
                value={modoIncognito}
                onValueChange={setModoIncognito}
                trackColor={{ false: '#999999', true: tema.primario }}
                thumbColor="#FFFFFF"
              />
            </View>

            <View style={[styles.divider, { backgroundColor: tema.borde }]} />

            <View style={styles.settingItem}>
              <Text style={[styles.settingText, { color: tema.texto }]}>📍  Mostrar mi distancia</Text>
              <Switch
                value={mostrarDistancia}
                onValueChange={setMostrarDistancia}
                trackColor={{ false: '#999999', true: tema.primario }}
                thumbColor="#FFFFFF"
              />
            </View>
          </View>

          <TouchableOpacity
            style={[styles.logoutButton, { backgroundColor: tema.secundario }]}
            onPress={cerrarSesion}
          >
            <Text style={[styles.logoutText, { color: tema.primario }]}>
              Cerrar sesión o cambiar de cuenta
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.deleteAccountButton}
            onPress={borrarCuentaActiva}
          >
            <Text style={styles.deleteAccountText}>
              🗑️  Borrar cuenta permanentemente
            </Text>
          </TouchableOpacity>
        </ScrollView>
      );
    }

    const galeriaExtra = usuario.galeriaExtra || [];

    return (
      <ScrollView style={styles.sectionContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.storeHeaderRow}>
          <Text style={[styles.sectionTitle, { color: tema.texto, marginTop: 0, marginBottom: 0 }]}>
            👤 Mi Perfil
          </Text>
          <TouchableOpacity
            style={[styles.backBtn, { backgroundColor: tema.secundario }]}
            onPress={() => setPestanaActiva('ajustes')}
          >
            <Text style={[styles.backBtnText, { color: tema.primario }]}>⚙️ Ajustes</Text>
          </TouchableOpacity>
        </View>

        <View
          style={[
            styles.profileHeaderCard,
            { backgroundColor: tema.tarjeta, borderColor: tema.borde },
          ]}
        >
          {renderAvatarConFiltroYMarco(76)}
          <View style={{ marginLeft: 14, flex: 1 }}>
            <View style={styles.profileNameBadgeRow}>
              <Text style={[styles.myName, { color: tema.texto }]}>{usuario.nombre}</Text>
              <View style={[styles.equippedTag, { backgroundColor: tema.secundario }]}>
                <Text style={[styles.equippedTagText, { color: tema.primario }]}>
                  {accesorioEquipado.insignia}
                </Text>
              </View>
            </View>
            <Text style={[styles.myStatus, { color: tema.subtexto }]}>
              {usuario.correo} · {filtroActivo.nombre}
            </Text>
            <Text style={[styles.bioPreviewText, { color: tema.texto }]} numberOfLines={3}>
              {usuario.bio}
            </Text>
          </View>
        </View>

        <View
          style={[
            styles.photoActionsCard,
            { backgroundColor: tema.tarjeta, borderColor: tema.borde },
          ]}
        >
          <Text style={[styles.subHeader, { color: tema.texto, marginTop: 0, marginBottom: 8 }]}>
            Foto principal y datos
          </Text>
          <View style={styles.photoBtnRow}>
            <TouchableOpacity
              style={[styles.photoActionBtn, { backgroundColor: tema.primario }]}
              onPress={cambiarFotoPrincipalMuestra}
            >
              <Text style={styles.photoActionBtnText}>🖼️ Cambiar foto</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.photoActionBtn, { backgroundColor: tema.secundario }]}
              onPress={() => setEditandoPerfil((v) => !v)}
            >
              <Text style={[styles.photoActionBtnTextAlt, { color: tema.primario }]}>
                ✏️ Editar
              </Text>
            </TouchableOpacity>
          </View>

          {editandoPerfil && (
            <View style={{ marginTop: 12 }}>
              <TextInput
                placeholder="Tu nombre"
                placeholderTextColor={tema.subtexto}
                value={nombrePerfilInput}
                onChangeText={setNombrePerfilInput}
                style={[
                  styles.editProfileInput,
                  { backgroundColor: tema.fondo, color: tema.texto, borderColor: tema.borde },
                ]}
              />
              <TextInput
                placeholder="Escribe tu biografía..."
                placeholderTextColor={tema.subtexto}
                value={bioInput}
                onChangeText={setBioInput}
                multiline
                style={[
                  styles.editProfileInput,
                  { backgroundColor: tema.fondo, color: tema.texto, borderColor: tema.borde, minHeight: 64 },
                ]}
              />
              <TouchableOpacity
                style={[styles.saveBioBtn, { backgroundColor: tema.primario }]}
                onPress={guardarDatosPerfil}
              >
                <Text style={styles.photoActionBtnText}>Guardar cambios</Text>
              </TouchableOpacity>
            </View>
          )}

          <Text style={[styles.filterSectionLabel, { color: tema.subtexto }]}>
            Filtros para tu foto principal
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {FILTROS_FOTO.map((f) => {
              const sel = filtroActivo.id === f.id;
              return (
                <TouchableOpacity
                  key={f.id}
                  onPress={() => actualizarUsuario((c) => ({ ...c, filtroFoto: f.id }))}
                  style={[
                    styles.filterChip,
                    {
                      backgroundColor: sel ? tema.primario : tema.secundario,
                      borderColor: sel ? tema.primario : tema.borde,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.filterChipText,
                      { color: sel ? '#FFFFFF' : tema.texto },
                    ]}
                  >
                    {f.nombre}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        <View
          style={[
            styles.photoActionsCard,
            { backgroundColor: tema.tarjeta, borderColor: tema.borde },
          ]}
        >
          <View style={styles.unlimitedHeaderRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.calendarTitle, { color: tema.texto }]}>
                🖼️ Fotos ilimitadas en el perfil ({galeriaExtra.length} agregadas)
              </Text>
              <Text style={[styles.calendarSub, { color: tema.subtexto }]}>
                Agrega tantas fotos como quieras a tu galería.
              </Text>
            </View>
            <TouchableOpacity
              style={[styles.addUnlimitedBtn, { backgroundColor: tema.primario }]}
              onPress={agregarFotoIlimitadaPerfil}
            >
              <Text style={styles.photoActionBtnText}>+ Agregar foto</Text>
            </TouchableOpacity>
          </View>

          {galeriaExtra.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 12 }}>
              {galeriaExtra.map((uriFoto, idx) => (
                <View key={`${uriFoto}_${idx}`} style={styles.extraPhotoItem}>
                  <Image source={{ uri: uriFoto }} style={styles.extraPhotoImg} />
                  <TouchableOpacity
                    style={styles.removePhotoBadge}
                    onPress={() => eliminarFotoExtra(idx)}
                  >
                    <Text style={styles.removePhotoText}>✕</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          ) : (
            <Text style={[styles.emptyGalleryHint, { color: tema.subtexto }]}>
              Aún no agregas fotos adicionales. Pulsa "+ Agregar foto" para añadir las que desees.
            </Text>
          )}
        </View>

        <View
          style={[
            styles.safetyInfoCard,
            { backgroundColor: tema.tarjeta, borderColor: tema.borde, marginBottom: 28 },
          ]}
        >
          <Text style={[styles.safetyTitle, { color: tema.texto }]}>
            ✓ Totalmente seguro y gratuito
          </Text>
          <Text style={[styles.safetyText, { color: tema.subtexto }]}>
            Nadie va a agarrar tu privacidad ni nada, y es totalmente gratuito para que lo disfrutes.
          </Text>
        </View>
      </ScrollView>
    );
  };

  return (
    <SafeAreaView style={[styles.mainContainer, { backgroundColor: tema.fondo }]}>
      <StatusBar barStyle={tema.barraEstado} backgroundColor={tema.fondo} />

      <View style={styles.topHeader}>
        <Text style={[styles.headerLogo, { color: tema.texto }]}>
          <Text style={{ color: tema.primario }}>♥ </Text>Amour
        </Text>
        <TouchableOpacity
          style={[styles.filterBtn, { backgroundColor: tema.secundario }]}
          onPress={() => setPestanaActiva('tienda')}
        >
          <Text style={[styles.filterText, { color: tema.primario }]}>
            🪙 {usuario.monedas.toLocaleString()}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={{ flex: 1 }}>{renderContenido()}</View>

      <Modal
        visible={esperandoRecompensa}
        transparent
        animationType="fade"
        onRequestClose={() => {}}
      >
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: tema.tarjeta }]}>
            <Text style={[styles.modalTitle, { color: tema.texto }]}>
              Preparando Recompensa
            </Text>
            <Text style={[styles.modalSubtitle, { color: tema.subtexto }]}>
              Recompensa: +{RECOMPENSA_POR_OPORTUNIDAD} monedas
            </Text>
            <Text style={[styles.adCountdownText, { color: tema.primario }]}>
              {segundosEspera}s
            </Text>
            <Text style={[styles.modalWarningBody, { color: tema.subtexto }]}>
              Espera los {SEGUNDOS_ESPERA_OPORTUNIDAD} segundos para recibir tus {RECOMPENSA_POR_OPORTUNIDAD} monedas.
            </Text>
          </View>
        </View>
      </Modal>

      <View
        style={[
          styles.bottomNav,
          { backgroundColor: tema.tarjeta, borderTopColor: tema.borde },
        ]}
      >
        <TouchableOpacity
          style={styles.navItem}
          onPress={() => {
            setChatAbiertoId(null);
            setPestanaActiva('descubrir');
          }}
        >
          <Text
            style={[
              styles.navIcon,
              { color: pestanaActiva === 'descubrir' ? tema.primario : tema.subtexto },
            ]}
          >
            ♥
          </Text>
          <Text
            style={[
              styles.navText,
              { color: pestanaActiva === 'descubrir' ? tema.primario : tema.subtexto },
            ]}
          >
            Descubrir
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navItem} onPress={() => setPestanaActiva('chats')}>
          <Text
            style={[
              styles.navIcon,
              { color: pestanaActiva === 'chats' ? tema.primario : tema.subtexto },
            ]}
          >
            💬
          </Text>
          <Text
            style={[
              styles.navText,
              { color: pestanaActiva === 'chats' ? tema.primario : tema.subtexto },
            ]}
          >
            Chats
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => {
            setChatAbiertoId(null);
            setPestanaActiva('tienda');
          }}
        >
          <Text
            style={[
              styles.navIcon,
              { color: pestanaActiva === 'tienda' ? tema.primario : tema.subtexto },
            ]}
          >
            🛍️
          </Text>
          <Text
            style={[
              styles.navText,
              { color: pestanaActiva === 'tienda' ? tema.primario : tema.subtexto },
            ]}
          >
            Tienda
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => {
            setChatAbiertoId(null);
            setPestanaActiva('perfil');
          }}
        >
          <Text
            style={[
              styles.navIcon,
              {
                color:
                  pestanaActiva === 'perfil' || pestanaActiva === 'ajustes'
                    ? tema.primario
                    : tema.subtexto,
              },
            ]}
          >
            👤
          </Text>
          <Text
            style={[
              styles.navText,
              {
                color:
                  pestanaActiva === 'perfil' || pestanaActiva === 'ajustes'
                    ? tema.primario
                    : tema.subtexto,
              },
            ]}
          >
            Perfil
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  loginContainer: { flex: 1, overflow: 'hidden' },
  loginGlowTop: { position: 'absolute', top: -110, right: -90, width: 280, height: 280, borderRadius: 140 },
  loginScroll: { flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  logoCircle: { width: 88, height: 88, borderRadius: 44, backgroundColor: '#FFFFFF', justifyContent: 'center', alignItems: 'center', marginBottom: 14, elevation: 8 },
  heartIcon: { fontSize: 42 },
  appTitle: { fontSize: 38, fontWeight: '800', color: '#FFFFFF', letterSpacing: 1 },
  appSubtitle: { fontSize: 13, color: 'rgba(255,255,255,0.94)', textAlign: 'center', marginTop: 6, marginBottom: 20, lineHeight: 19 },
  authSwitchRow: { flexDirection: 'row', width: '100%', backgroundColor: 'rgba(0,0,0,0.22)', borderRadius: 16, padding: 4, marginBottom: 14 },
  authTab: { flex: 1, paddingVertical: 11, borderRadius: 13, alignItems: 'center' },
  authTabActive: { backgroundColor: '#FFFFFF' },
  authTabText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
  errorBanner: { backgroundColor: '#FFE5EC', padding: 10, borderRadius: 10, marginBottom: 10 },
  errorBannerText: { color: '#B80021', fontSize: 12, textAlign: 'center', fontWeight: '600' },
  emailBox: { width: '100%', backgroundColor: '#FFFFFF', borderRadius: 22, padding: 16, marginBottom: 16, elevation: 5 },
  authInput: { backgroundColor: '#F5F5F7', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: '#222', marginBottom: 10 },
  submitEmailBtn: { paddingVertical: 14, borderRadius: 14, alignItems: 'center', marginTop: 4 },
  submitEmailText: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  savedAccountsBox: { width: '100%', backgroundColor: 'rgba(255,255,255,0.16)', borderRadius: 18, padding: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)' },
  savedAccountsTitle: { color: '#FFFFFF', fontSize: 13, fontWeight: '700', marginBottom: 10 },
  savedAccountRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFFFF', padding: 10, borderRadius: 12, marginBottom: 8 },
  savedAccountName: { fontSize: 14, fontWeight: '700', color: '#1F1F1F' },
  savedAccountEmail: { fontSize: 12, color: '#666666' },
  savedCoinsPill: { backgroundColor: '#FFF3CD', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  savedCoinsText: { fontSize: 12, fontWeight: '700', color: '#856404' },
  callScreen: { flex: 1, backgroundColor: '#121216' },
  callOverlayLayer: { flex: 1, justifyContent: 'space-between', padding: 24 },
  callTopInfo: { alignItems: 'center', marginTop: 12 },
  callBadge: { color: '#FF8FA8', fontSize: 12, fontWeight: '800', letterSpacing: 1 },
  callRateText: { color: '#CCCCCC', fontSize: 13, marginTop: 6 },
  callCenter: { alignItems: 'center' },
  callAvatar: { width: 112, height: 112, borderRadius: 56, borderWidth: 3, marginBottom: 12 },
  callName: { color: '#FFFFFF', fontSize: 26, fontWeight: '800' },
  callTimer: { color: '#FFFFFF', fontSize: 36, fontWeight: '700', marginTop: 6 },
  minutesCounterBadge: { color: '#FFD166', fontSize: 14, fontWeight: '800', marginTop: 4, marginBottom: 14 },
  ringingStatusText: { color: '#E4E4E7', fontSize: 14, textAlign: 'center', marginTop: 12, lineHeight: 20 },
  callBillingCard: { backgroundColor: 'rgba(30, 30, 38, 0.92)', borderRadius: 18, padding: 14, width: '100%', alignItems: 'center' },
  callBillingLine: { color: '#D4D4D8', fontSize: 13, marginVertical: 2 },
  callHighlight: { color: '#FFD166', fontWeight: '800' },
  callBottomRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  flipCamBtn: { backgroundColor: '#27272A', paddingHorizontal: 16, justifyContent: 'center', borderRadius: 20 },
  flipCamText: { color: '#FFFFFF', fontWeight: '700', fontSize: 13 },
  hangupBtn: { backgroundColor: '#E11D48', paddingVertical: 16, borderRadius: 20, alignItems: 'center' },
  acceptCallBtn: { backgroundColor: '#16A34A', paddingVertical: 16, borderRadius: 20, alignItems: 'center' },
  hangupText: { color: '#FFFFFF', fontSize: 15, fontWeight: '800' },
  mainContainer: { flex: 1 },
  topHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 22, paddingVertical: 14 },
  headerLogo: { fontSize: 24, fontWeight: '800' },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 14 },
  filterText: { fontWeight: '700', fontSize: 13 },
  discoverContainer: { flex: 1, alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingBottom: 18 },
  card: { width: width - 36, flex: 1, borderRadius: 28, overflow: 'hidden', elevation: 6 },
  cardImage: { width: '100%', height: '100%' },
  cardOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(20, 10, 14, 0.82)', padding: 20 },
  cardName: { fontSize: 26, fontWeight: '800', color: '#FFFFFF' },
  cardAge: { fontWeight: '400' },
  cardDistance: { color: '#FFD1DC', fontSize: 13, marginTop: 3, marginBottom: 6 },
  cardBio: { color: '#F8EDEB', fontSize: 14, lineHeight: 19 },
  greetBtn: { marginTop: 12, paddingVertical: 11, borderRadius: 14, alignItems: 'center' },
  greetBtnText: { color: '#FFFFFF', fontWeight: '800', fontSize: 13 },
  actionButtons: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 18, gap: 22 },
  circleBtn: { justifyContent: 'center', alignItems: 'center', borderRadius: 40, elevation: 4 },
  passBtn: { width: 60, height: 60 },
  passText: { fontSize: 26, fontWeight: '700' },
  starBtn: { width: 48, height: 48 },
  starText: { fontSize: 22 },
  likeBtn: { width: 66, height: 66 },
  likeText: { fontSize: 30, color: '#FFFFFF' },
  sectionContainer: { flex: 1, paddingHorizontal: 22 },
  chatRoomContainer: { flex: 1 },
  chatRoomHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1, gap: 8 },
  chatRoomAvatar: { width: 40, height: 40, borderRadius: 20 },
  chatRateHint: { fontSize: 11 },
  callActionPill: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12 },
  callActionText: { fontSize: 15, fontWeight: '700' },
  callActionTextWhite: { fontSize: 15, color: '#FFFFFF', fontWeight: '700' },
  messagesList: { flex: 1, paddingHorizontal: 16, paddingTop: 12 },
  bubble: { maxWidth: '78%', padding: 12, borderRadius: 18, marginBottom: 10, borderWidth: 1 },
  bubbleMine: { alignSelf: 'flex-end', borderWidth: 0 },
  bubbleTheirs: { alignSelf: 'flex-start' },
  bubbleText: { fontSize: 14, lineHeight: 20 },
  msgPhoto: { width: 190, height: 130, borderRadius: 12, marginBottom: 6 },
  msgMeta: { fontSize: 11, fontWeight: '600' },
  audioBubbleRow: { gap: 2 },
  bubbleTime: { fontSize: 10, marginTop: 4, alignSelf: 'flex-end' },
  composerBox: { paddingHorizontal: 14, paddingVertical: 10, borderTopWidth: 1 },
  mediaToolsRow: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  mediaChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  mediaChipText: { fontSize: 12, fontWeight: '700' },
  textSendRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  messageInput: { flex: 1, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 9, fontSize: 14 },
  sendBtn: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
  sendBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },
  sectionTitle: { fontSize: 19, fontWeight: '800', marginTop: 8, marginBottom: 10 },
  subHeader: { fontSize: 14, fontWeight: '700', marginBottom: 10, marginTop: 8 },
  matchesScroll: { marginBottom: 18 },
  matchAvatarContainer: { alignItems: 'center', marginRight: 16 },
  matchAvatar: { width: 66, height: 66, borderRadius: 33, borderWidth: 2.5 },
  matchName: { marginTop: 6, fontSize: 13, fontWeight: '600' },
  chatRow: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 20, marginBottom: 12, borderWidth: 1 },
  chatAvatar: { width: 54, height: 54, borderRadius: 27 },
  chatTextContainer: { flex: 1, marginLeft: 14 },
  chatHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  chatName: { fontSize: 16, fontWeight: '700' },
  chatTime: { fontSize: 12 },
  chatMessage: { fontSize: 14 },
  chatMessageUnread: { fontWeight: '700' },
  unreadDot: { width: 10, height: 10, borderRadius: 5, marginLeft: 8 },
  profileHeaderCard: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 22, marginBottom: 12, borderWidth: 1.5 },
  avatarFilterWrapper: { overflow: 'hidden', justifyContent: 'center', alignItems: 'center' },
  profileNameBadgeRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 8 },
  myName: { fontSize: 18, fontWeight: '700' },
  equippedTag: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  equippedTagText: { fontSize: 11, fontWeight: '800' },
  myStatus: { fontSize: 12, marginTop: 2 },
  bioPreviewText: { fontSize: 12, marginTop: 4, lineHeight: 16 },
  photoActionsCard: { borderRadius: 20, padding: 14, borderWidth: 1, marginBottom: 14 },
  photoBtnRow: { flexDirection: 'row', gap: 8 },
  photoActionBtn: { flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: 'center' },
  photoActionBtnText: { color: '#FFFFFF', fontSize: 12, fontWeight: '800' },
  photoActionBtnTextAlt: { fontSize: 12, fontWeight: '800' },
  editProfileInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9, fontSize: 13, marginBottom: 8 },
  saveBioBtn: { paddingVertical: 10, borderRadius: 12, alignItems: 'center' },
  filterSectionLabel: { fontSize: 12, fontWeight: '700', marginTop: 12, marginBottom: 8 },
  filterChip: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 12, borderWidth: 1, marginRight: 8 },
  filterChipText: { fontSize: 12, fontWeight: '700' },
  unlimitedHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  addUnlimitedBtn: { paddingHorizontal: 12, paddingVertical: 9, borderRadius: 12 },
  extraPhotoItem: { position: 'relative', marginRight: 10 },
  extraPhotoImg: { width: 92, height: 92, borderRadius: 14 },
  removePhotoBadge: { position: 'absolute', top: 4, right: 4, backgroundColor: 'rgba(0,0,0,0.7)', width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center' },
  removePhotoText: { color: '#FFFFFF', fontSize: 11, fontWeight: '800' },
  emptyGalleryHint: { fontSize: 12, marginTop: 10, lineHeight: 17 },
  safetyInfoCard: { borderRadius: 20, padding: 14, borderWidth: 1, marginBottom: 14 },
  safetyTitle: { fontSize: 14, fontWeight: '800', marginBottom: 4 },
  safetyText: { fontSize: 12, lineHeight: 18 },
  adsBox: { borderRadius: 20, padding: 14, borderWidth: 1, marginBottom: 14 },
  watchAdBtn: { paddingVertical: 12, paddingHorizontal: 12, borderRadius: 14, alignItems: 'center' },
  watchAdBtnText: { fontSize: 12, fontWeight: '800', textAlign: 'center' },
  calendarCard: { borderRadius: 20, padding: 14, borderWidth: 1, marginBottom: 14 },
  calendarTopRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, gap: 8 },
  calendarTitle: { fontSize: 14, fontWeight: '800' },
  calendarSub: { fontSize: 11, marginTop: 2 },
  timerPill: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10 },
  timerPillText: { fontSize: 11, fontWeight: '800' },
  daysRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 4 },
  dayChip: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 10, borderWidth: 1 },
  dayLabel: { fontSize: 10, fontWeight: '700' },
  dayReward: { fontSize: 10, fontWeight: '800', marginTop: 2 },
  storeHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, marginBottom: 12, gap: 8 },
  backBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12 },
  backBtnText: { fontWeight: '700', fontSize: 13 },
  balanceBadge: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 12, borderWidth: 1 },
  balanceText: { fontWeight: '700', fontSize: 13 },
  accessoryCard: { flexDirection: 'row', alignItems: 'center', padding: 12, borderRadius: 18, borderWidth: 1.5, marginBottom: 10 },
  accessoryPreviewCircle: { width: 46, height: 46, borderRadius: 23, borderWidth: 3, justifyContent: 'center', alignItems: 'center' },
  accessoryPreviewGlyph: { fontSize: 20, fontWeight: '800' },
  accessoryTitleRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 },
  accessoryName: { fontSize: 14, fontWeight: '700' },
  badgePill: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8 },
  badgePillText: { fontSize: 10, fontWeight: '800' },
  accessoryDesc: { fontSize: 12, marginTop: 2 },
  accessoryActionBtn: { paddingHorizontal: 11, paddingVertical: 8, borderRadius: 12 },
  accessoryActionText: { fontSize: 11, fontWeight: '800' },
  themeBox: { flexDirection: 'row', justifyContent: 'space-between', padding: 12, borderRadius: 20, borderWidth: 1, marginBottom: 18, gap: 8 },
  themeOption: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 14, borderWidth: 1.5 },
  colorCircle: { width: 26, height: 26, borderRadius: 13, borderWidth: 1.5, marginBottom: 6 },
  themeLabel: { fontSize: 12, fontWeight: '700' },
  settingsBox: { borderRadius: 22, paddingHorizontal: 16, paddingVertical: 6, borderWidth: 1 },
  settingItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 14 },
  settingText: { fontSize: 15, fontWeight: '500' },
  divider: { height: 1 },
  logoutButton: { alignItems: 'center', marginTop: 24, marginBottom: 12, paddingVertical: 14, borderRadius: 18 },
  logoutText: { fontWeight: '700', fontSize: 15 },
  deleteAccountButton: { alignItems: 'center', marginBottom: 32, paddingVertical: 13, borderRadius: 18, borderWidth: 1, borderColor: '#E11D48', backgroundColor: 'rgba(225, 29, 72, 0.08)' },
  deleteAccountText: { color: '#E11D48', fontWeight: '800', fontSize: 14 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.72)', justifyContent: 'center', alignItems: 'center', padding: 22 },
  modalCard: { width: '100%', borderRadius: 24, padding: 22, elevation: 10, alignItems: 'center' },
  modalTitle: { fontSize: 20, fontWeight: '800', textAlign: 'center' },
  modalSubtitle: { fontSize: 13, textAlign: 'center', marginTop: 6 },
  adCountdownText: { fontSize: 38, fontWeight: '800', marginVertical: 14 },
  modalWarningBody: { fontSize: 13, lineHeight: 19, textAlign: 'center' },
  bottomNav: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 10, borderTopWidth: 1, borderTopLeftRadius: 24, borderTopRightRadius: 24, elevation: 10 },
  navItem: { alignItems: 'center' },
  navIcon: { fontSize: 20 },
  navText: { fontSize: 11, marginTop: 3, fontWeight: '600' },
});